import {Link} from 'react-router-dom'
import './index.css'

const levelButtonItem = props => {
  const {buttonDetails} = props
  const {name, buttonStyle} = buttonDetails

  return (
    <li className="button-styles">
      <Link to="/start-game">
        <button type="button" className={buttonStyle}>
          {name}
        </button>
      </Link>
    </li>
  )
}

export default levelButtonItem
