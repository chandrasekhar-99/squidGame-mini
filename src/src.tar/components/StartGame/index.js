import {Component} from 'react'
import {Link} from 'react-router-dom'
import './index.css'

class StartGame extends Component {
  render() {
    return (
      <div className="start-game-container">
        <img
          src="https://i.imgur.com/zCBNwBQ.jpg"
          alt="start-game"
          className="start-game-avatar"
        />
        <Link to="/easy-level">
          <button type="button" className="start-btn">
            Start Game
          </button>
        </Link>
      </div>
    )
  }
}
export default StartGame
