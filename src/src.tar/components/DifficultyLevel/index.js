import {Component} from 'react'
import LevelButton from '../LevelButton'
import './index.css'

const levelButtonsList = [
  {
    id: 0,
    name: 'Easy',
    buttonStyle: 'easy-button',
    level: 'easy-level',
  },
  {
    id: 2,
    name: 'Medium',
    buttonStyle: 'medium-button',
    level: 'medium-level',
  },
  {
    id: 3,
    name: 'Hard',
    buttonStyle: 'hard-button',
    level: 'hard-level',
  },
]

class DifficultyLevel extends Component {
  render() {
    return (
      <div className="level-container">
        <h1 className="heading">Select Difficulty Level</h1>
        <ul className="button-container">
          {levelButtonsList.map(eachButton => (
            <LevelButton key={eachButton.id} buttonDetails={eachButton} />
          ))}
        </ul>
      </div>
    )
  }
}

export default DifficultyLevel
